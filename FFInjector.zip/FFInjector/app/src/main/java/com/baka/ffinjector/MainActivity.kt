package com.yourname.ffinjector

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {

    private lateinit var btnInject: Button
    private lateinit var btnRemove: Button
    private lateinit var tvStatus: TextView

    // Request code for Shizuku permission
    private val SHIZUKU_REQ = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnInject = findViewById(R.id.btn_inject)
        btnRemove = findViewById(R.id.btn_remove)
        tvStatus  = findViewById(R.id.tv_status)

        btnInject.setOnClickListener { doInject() }
        btnRemove.setOnClickListener { doRemove() }

        checkShizukuPermission()
    }

    // -------------------------------------------------------------------------

    private fun doInject() {
        setStatus("Injecting...")
        lifecycleScope.launch(Dispatchers.IO) {
            val patchBytes = loadPatchAsset()   // load from assets/patch.bytes
            val result = FFInjector.inject(this@MainActivity, patchBytes)
            withContext(Dispatchers.Main) {
                result.fold(
                    onSuccess = { setStatus("✓ $it") },
                    onFailure = { setStatus("✗ ${it.message}") }
                )
            }
        }
    }

    private fun doRemove() {
        setStatus("Removing patch...")
        lifecycleScope.launch(Dispatchers.IO) {
            val result = FFInjector.remove()
            withContext(Dispatchers.Main) {
                result.fold(
                    onSuccess = { setStatus("✓ $it") },
                    onFailure = { setStatus("✗ ${it.message}") }
                )
            }
        }
    }

    // -------------------------------------------------------------------------

    /**
     * Load Assembly-CSharp-patch.bytes from assets.
     * Put your patch file at: app/src/main/assets/patch.bytes
     */
    private fun loadPatchAsset(): ByteArray {
        return assets.open("patch.bytes").use { it.readBytes() }
    }

    private fun setStatus(msg: String) {
        tvStatus.text = msg
    }

    // -------------------------------------------------------------------------
    // Shizuku permission
    // -------------------------------------------------------------------------

    private fun checkShizukuPermission() {
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku not running — start Shizuku first")
            return
        }
        if (Shizuku.checkSelfPermission() !=
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Shizuku.requestPermission(SHIZUKU_REQ)
        } else {
            setStatus("Shizuku ready")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SHIZUKU_REQ) {
            setStatus(
                if (grantResults.firstOrNull() ==
                        android.content.pm.PackageManager.PERMISSION_GRANTED)
                    "Shizuku ready"
                else
                    "Shizuku permission denied"
            )
        }
    }
}
