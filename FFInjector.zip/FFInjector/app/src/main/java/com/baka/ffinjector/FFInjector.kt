package com.yourname.ffinjector

import android.content.Context
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.io.*

/**
 * FF HybridCLR Patch Injector
 *
 * What it does:
 *   1. Checks Shizuku permission
 *   2. Writes localconfig.json  → FF data dir  (enables testCodePatch)
 *   3. Writes Assembly-CSharp-patch.bytes → FF data dir  (the ESP hotfix DLL)
 *
 * FF data dir: /data/data/com.dts.freefireth/files/
 * Shizuku shell runs as shell UID (2000), so we use `cp` via shell to cross
 * the UID boundary — shell can write to world-writable app-owned dirs via
 * run-as, or we stage to /data/local/tmp first then cp.
 */

object FFInjector {

    private const val TAG = "FFInjector"
    private const val FF_PKG = "com.dts.freefireth"

    // Drop targets inside FF data dir
    private const val TARGET_CONFIG = "/data/data/$FF_PKG/files/localconfig.json"
    private const val TARGET_PATCH  = "/data/data/$FF_PKG/files/Assembly-CSharp-patch.bytes"

    // Staging area (shell-writable, no root needed)
    private const val STAGE_DIR     = "/data/local/tmp/ffinject"

    // localconfig that enables HybridCLR hotfix loading
    private val LOCAL_CONFIG = """{"testCodePatch":true,"resetGuest":true}"""

    // -------------------------------------------------------------------------
    // Public entry point
    // -------------------------------------------------------------------------

    /**
     * Call this from a coroutine / background thread.
     * @param context  app context
     * @param patchBytes  raw bytes of Assembly-CSharp-patch.bytes (load from assets)
     * @return Result with status message
     */
    fun inject(context: Context, patchBytes: ByteArray): Result<String> {
        return try {
            checkShizuku()
            stagePatch(patchBytes)
            stageConfig()
            deployToFF()
            cleanStage()
            Result.success("Injected — restart FF now")
        } catch (e: Exception) {
            Log.e(TAG, "inject failed", e)
            Result.failure(e)
        }
    }

    fun remove(): Result<String> {
        return try {
            checkShizuku()
            shell("rm -f '$TARGET_CONFIG' '$TARGET_PATCH'")
            Result.success("Patch removed — restart FF to clean")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // -------------------------------------------------------------------------
    // Steps
    // -------------------------------------------------------------------------

    private fun checkShizuku() {
        check(Shizuku.pingBinder()) { "Shizuku not running" }
        check(Shizuku.checkSelfPermission() ==
                android.content.pm.PackageManager.PERMISSION_GRANTED) {
            "Shizuku permission not granted"
        }
    }

    private fun stagePatch(bytes: ByteArray) {
        shell("mkdir -p $STAGE_DIR")
        // Write patch bytes to staging via shell stdin
        writeFileViaShell("$STAGE_DIR/patch.bytes", bytes)
    }

    private fun stageConfig() {
        writeStringViaShell("$STAGE_DIR/localconfig.json", LOCAL_CONFIG)
    }

    private fun deployToFF() {
        // Use run-as to copy files into FF's private data dir
        shell("run-as $FF_PKG cp '$STAGE_DIR/localconfig.json' '$TARGET_CONFIG'")
        shell("run-as $FF_PKG cp '$STAGE_DIR/patch.bytes' '$TARGET_PATCH'")
        // Set permissions so FF can read them
        shell("run-as $FF_PKG chmod 644 '$TARGET_CONFIG' '$TARGET_PATCH'")
        Log.i(TAG, "Deployed to FF data dir")
    }

    private fun cleanStage() {
        shell("rm -rf $STAGE_DIR")
    }

    // -------------------------------------------------------------------------
    // Shell helpers
    // -------------------------------------------------------------------------

    /** Run a single shell command via Shizuku and throw if exit != 0 */
    private fun shell(cmd: String): String {
        Log.d(TAG, "shell: $cmd")
        val process: ShizukuRemoteProcess = Shizuku.newProcess(
            arrayOf("sh", "-c", cmd), null, null
        )
        val out  = process.inputStream.bufferedReader().readText()
        val err  = process.errorStream.bufferedReader().readText()
        val exit = process.waitFor()
        if (exit != 0) throw IOException("shell failed ($exit): $err\ncmd: $cmd")
        return out
    }

    /**
     * Write raw bytes to a path via shell.
     * Uses base64 piped to decode — works without root, shell UID only.
     */
    private fun writeFileViaShell(path: String, bytes: ByteArray) {
        val b64 = android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        // Write in chunks to stay under arg-size limits
        val chunkSize = 8192
        // Clear file first
        shell("printf '' > '$path'")
        var offset = 0
        while (offset < b64.length) {
            val chunk = b64.substring(offset, minOf(offset + chunkSize, b64.length))
            shell("printf '%s' '$chunk' >> '${path}.b64'")
            offset += chunkSize
        }
        shell("base64 -d '${path}.b64' > '$path' && rm '${path}.b64'")
    }

    private fun writeStringViaShell(path: String, content: String) {
        writeFileViaShell(path, content.toByteArray(Charsets.UTF_8))
    }
}
